package com.ui.ctpgapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.cognitive.printer.io.POSPrinterIO;
import com.cognitive.printer.io.POSPrinterIO.Alignment;
import com.cognitive.printer.io.POSPrinterIO.BarCodeType;
import com.cognitive.printer.io.POSPrinterIO.BarcodeWide;
import com.cognitive.printer.io.POSPrinterIO.HRI;

public class BarcodeActivity extends Activity
{

	private EditText barcode_data;
	private Spinner select_justify;
	private Spinner select_hri;
	private Spinner select_width;
	private Spinner select_barcode;
	private EditText barcode_height;
	private FrameLayout print_button;
	
	private boolean isProcessing=false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.barcode_printing);
		
		select_barcode=(Spinner) findViewById(R.id.select_barcode);
		SpinnerAdapter ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new String[] {"UPC-A", "UPC-E", "JAN8", "JAN13","Code39","Code93","Code128","CODABAR","CodeEAN128","ITF"});
		select_barcode.setAdapter(ad);
		
		select_justify=(Spinner) findViewById(R.id.select_justify);
		ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new String[] {"Left", "Center", "Right"});
		select_justify.setAdapter(ad);
		
		select_hri=(Spinner) findViewById(R.id.select_hri);
		ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new String[] {"HRI None", "HRI Above", "HRI Below", "HRI Both"});
		select_hri.setAdapter(ad);
		
		select_width=(Spinner) findViewById(R.id.select_width);
		ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new String[] {"Wide 2", "Wide 3", "Wide 4", "Wide 5","Wide 6"});
		select_width.setAdapter(ad);
		
		barcode_height=(EditText) findViewById(R.id.barcode_height);
		barcode_data=(EditText) findViewById(R.id.barcode_data);
		
		print_button=(FrameLayout) findViewById(R.id.print_button);
		print_button.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View arg0) 
			{
				try 
				{	
					if(isProcessing)
					{
						return;
					}
					isProcessing=true;
					POSPrinterIO buffer=new POSPrinterIO();
					buffer.addResetPrinter();
					buffer.addAlignment(getJustification());
					buffer.addBarcode(getBarcodeHeight(), getBarcodeWide(), getBarcodeHRI(), getBarcodeType(), getBarcodeData());
					buffer.addFeedLines(2);
					
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						BluetoothActivity.printer.sendCommand(buffer);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						sendToPrinter(buffer);
					}
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
				isProcessing=false;
			}
		});
	}
	
	private void sendToPrinter(final POSPrinterIO buffer)
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					WiFiActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
		thread.start();
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(BarcodeActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	
	private Alignment getJustification()
	{
		int position=select_justify.getSelectedItemPosition();
		if(position==0)
		{
			return Alignment.Left;
		}
		if(position==1)
		{
			return Alignment.Center;
		}
		if(position==2)
		{
			return Alignment.Right;
		}
		return Alignment.Center;
	}
	
	private BarCodeType getBarcodeType()
	{
		int position=select_barcode.getSelectedItemPosition();
		if(position==0)
		{
			//barcode_data.setText("036000241457");
			return BarCodeType.UPC_A;
		}
		if(position==1)
		{
			//barcode_data.setText("065100004327");
			return BarCodeType.UPC_E;
		}
		if(position==2)
		{
			//barcode_data.setText("7351353");
			return BarCodeType.JAN8;
		}
		if(position==3)
		{
			//barcode_data.setText("4006381333931");
			return BarCodeType.JAN13;
		}
		if(position==4)
		{
			return BarCodeType.Code_39;
		}
		if(position==5)
		{
			return BarCodeType.Code_93;
		}
		if(position==6)
		{
			return BarCodeType.Code_128;
		}
		if(position==7)
		{
			return BarCodeType.CODABAR;
		}
		if(position==8)
		{
			return BarCodeType.Code_EAN_128;
		}
		if(position==9)
		{
			return BarCodeType.ITF;
		}
		return BarCodeType.Code_39;
	}

	private HRI getBarcodeHRI()
	{
		int position=select_hri.getSelectedItemPosition();
		if(position==0)
		{
			return HRI.HRI_None;
		}
		if(position==1)
		{
			return HRI.HRI_Above;
		}
		if(position==2)
		{
			return HRI.HRI_Below;
		}
		if(position==3)
		{
			return HRI.HRI_Both;
		}
		return HRI.HRI_None;
	}
	
	private BarcodeWide getBarcodeWide()
	{
		int position=select_width.getSelectedItemPosition();
		if(position==0)
		{
			return BarcodeWide.Wide_2;
		}
		if(position==1)
		{
			return BarcodeWide.Wide_3;
		}
		if(position==2)
		{
			return BarcodeWide.Wide_4;
		}
		if(position==3)
		{
			return BarcodeWide.Wide_5;
		}
		if(position==4)
		{
			return BarcodeWide.Wide_6;
		}
		return BarcodeWide.Wide_2;
	}
	
	private int  getBarcodeHeight()
	{
		int height=0;
		String hgt=barcode_height.getText().toString().trim();
		try 
		{
			height=Integer.parseInt(hgt);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		if(height>0 && height<=255)
		{
			return height;
		}
		else
		{
			height=80;
			return height;
		}
	}
	
	private byte[] getBarcodeData()
	{
		return barcode_data.getText().toString().trim().getBytes();
	}
}
