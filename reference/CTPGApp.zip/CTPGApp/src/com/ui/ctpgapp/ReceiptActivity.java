package com.ui.ctpgapp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import com.cognitive.printer.io.POSPrinterIO;
import com.cognitive.printer.io.POSPrinterIO.Alignment;
import com.cognitive.printer.io.POSPrinterIO.BarCodeType;
import com.cognitive.printer.io.POSPrinterIO.BarcodeWide;
import com.cognitive.printer.io.POSPrinterIO.CorrectionLevelOption;
import com.cognitive.printer.io.POSPrinterIO.CutType;
import com.cognitive.printer.io.POSPrinterIO.HRI;
import com.cognitive.printer.io.POSPrinterIO.Model;
import com.cognitive.printer.io.POSPrinterIO.Pitch;
import com.cognitive.printer.io.POSPrinterIO.PrintMode;
import com.cognitive.util.BitmapConvertor;

public class ReceiptActivity extends Activity
{
	private int current_index=0;
	private int[] receipt={R.drawable.receipt_2,R.drawable.receipt_5};
	
	private ImageView gallery;
	private ImageView indication1;
	private ImageView indication2;
	
	private FrameLayout print_button;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.receipt_printing);
		final GestureDetector gdt = new GestureDetector(new GestureListener());
		gallery=(ImageView) findViewById(R.id.gallery);
		gallery.setOnTouchListener(new OnTouchListener() 
		{
			public boolean onTouch(View v, MotionEvent event) 
			{
				gdt.onTouchEvent(event);
                return true;
			}
		});
		
		indication1=(ImageView) findViewById(R.id.indication1);
		indication2=(ImageView) findViewById(R.id.indication2);
		
		print_button=(FrameLayout) findViewById(R.id.print_button);
		print_button.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View arg0) 
			{
				switch (current_index) 
				{
				case 0:
					printReceipt2();
					break;
					
				case 1:
					printReceipt5();
					break;
				
				default:
					break;
				}
			}
		});
	}
	
	private void goNext()
	{
		if(current_index>=0 && current_index<1)
		{
			current_index++;
			gallery.setImageResource(receipt[current_index]);
			showActive();
		}
	}
	
	private void goPrevious()
	{
		if(current_index>0 && current_index<=1)
		{
			current_index--;
			gallery.setImageResource(receipt[current_index]);
			showActive();
		}
	}
	
	private void showActive()
	{
		switch (current_index) 
		{
		case 0:
			indication1.setImageResource(R.drawable.active_dot);
			indication2.setImageResource(R.drawable.inactive_dot);
			break;
			
		case 1:
			indication1.setImageResource(R.drawable.inactive_dot);
			indication2.setImageResource(R.drawable.active_dot);
			break;
		
		default:
			break;
		}
	}
	
	private static final int SWIPE_MIN_DISTANCE = 120;
    private static final int SWIPE_THRESHOLD_VELOCITY = 200;

    private class GestureListener extends SimpleOnGestureListener 
    {
        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) 
        {
            if(e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) 
            {
            	goNext();
            	return false; // Right to left
            }  
            else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) 
            {
            	goPrevious();
                return false; // Left to right
            }
            return false;
        }
    }
    
    private byte[] getBinaryImage()
	{
		try 
		{
			InputStream is=getAssets().open("logo.bmp");
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();

			int nRead;
			byte[] data = new byte[16384];

			while ((nRead = is.read(data, 0, data.length)) != -1) {
			  buffer.write(data, 0, nRead);
			}

			buffer.flush();

			return buffer.toByteArray();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		return null;
	}
    
	private void printReceipt1()
	{
		try 
		{
			//Bitmap bmp=BitmapFactory.decodeStream(getAssets().open("logo.png"));
			//BitmapConvertor convert=new BitmapConvertor();
			//byte[] image=convert.getMonochromeBitmap(bmp);
			
			byte[] image=getBinaryImage();
			
			POSPrinterIO buffer=new POSPrinterIO();
			buffer.addResetPrinter();
			buffer.addLogo(image);
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				try 
				{
					BluetoothActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(buffer);
			}
			Thread.sleep(100L);
			
			buffer.clearBuffer();
			buffer.addAlignment(Alignment.Center);
			buffer.printLogo(PrintMode.Normal);
			buffer.addFeedLines(2);
			buffer.addPrintMode(Pitch.STANDARD, false, true, false, false);
			buffer.addTextData("Thermal Printers\r\n".getBytes());
			buffer.addFeedLines(2);
			
			buffer.addPrintMode(Pitch.STANDARD, false, false, false, false);
			buffer.addAlignment(Alignment.Left);
			buffer.addTextData("	 A798\r\n".getBytes());
			buffer.addTextData("		Single Station\r\n".getBytes());
			buffer.addTextData("		High-Speed\r\n".getBytes());
			buffer.addFeedLines(2);
			
			buffer.addTextData("	 A799\r\n".getBytes());
			buffer.addTextData("		Single Station\r\n".getBytes());
			buffer.addTextData("		Two-Color\r\n".getBytes());
			buffer.addTextData("		High-Speed\r\n".getBytes());
			buffer.addFeedLines(2);
			
			buffer.addTextData("	 A760\r\n".getBytes());
			buffer.addTextData("		Thermal/Impact hybrid\r\n".getBytes());
			buffer.addTextData("		Two-Color\r\n".getBytes());
			buffer.addTextData("		High-Speed\r\n".getBytes());
			buffer.addFeedLines(2);
			
			buffer.addTextData("	 A776/B780\r\n".getBytes());
			buffer.addTextData("		Thermal/Impact hybrid\r\n".getBytes());
			buffer.addTextData("		Two-Color\r\n".getBytes());
			buffer.addTextData("		High-Speed\r\n".getBytes());
			buffer.addTextData("		Narrow Footprint\r\n".getBytes());
			buffer.addFeedLines(2);
			
			buffer.addAlignment(Alignment.Center);
			buffer.addPrintMode(Pitch.STANDARD, false, false, false, false);
			buffer.addTextData("Easy to load\r\n".getBytes());
			buffer.addTextData("Easy to use\r\n".getBytes());
			buffer.addFeedLines(2);
			
			buffer.addTextData("The Leader for Printer Solutions\r\n".getBytes());
			buffer.addFeedLines(2);
			
			buffer.addTextEmphasized(true);
			buffer.addTextData("CognitiveTPG\r\n".getBytes());
			buffer.addTextEmphasized(false);
			buffer.addTextData("For more information please visit us at:\r\n".getBytes());
			//buffer.addTextData("The Leader for Printer Solutions\r\n".getBytes());
			buffer.addTextData("www.cognitive.com\r\n".getBytes());
			buffer.addFeedLines(6);
			buffer.addCut(CutType.PARTIAL_CUT);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				try 
				{
					BluetoothActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(buffer);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private void printReceipt2()
	{
		try 
		{
			//Bitmap bmp=BitmapFactory.decodeStream(getAssets().open("logo.png"));
			//BitmapConvertor convert=new BitmapConvertor();
			//byte[] image=convert.getMonochromeBitmap(bmp);
			
			byte[] image=getBinaryImage();
			
			POSPrinterIO pos=new POSPrinterIO();
			pos.addInitializePrinter();
			pos.addLogo(image);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				try 
				{
					BluetoothActivity.printer.sendCommand(pos);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(pos);
			}
			Thread.sleep(100L);
			
			pos.clearBuffer();
			pos.addAlignment(Alignment.Center);
			pos.printLogo(PrintMode.Normal);
			pos.addFeedLines(1);
			
			pos.addPrintMode(Pitch.STANDARD, false, true, true, false);
			pos.addTextData("A799".getBytes());
			pos.addFeedLine();
			pos.addFeedLine();
			
			pos.addPrintMode(Pitch.STANDARD, false, true, true, false);
			pos.addTextData("Thermal Printer".getBytes());
			pos.addFeedLine();
			pos.addFeedLine();
			pos.addPrintMode(Pitch.STANDARD, false, false, false, false);
			
			pos.addPrintMode(Pitch.STANDARD, false, false, false, false);
			pos.addFeedLine();
			pos.addTextData("0        1         2         3         4   4".getBytes());
			pos.addFeedLine();
			pos.addTextData("12 4 6 8 0 2 4 6 8 0 2 4 6 8 0 2 4 6 8 0 2 4".getBytes());
			pos.addFeedLine();
			pos.addTextData("|        |         |         |         |   |".getBytes());
			pos.addFeedLine();
			
			pos.addPrintMode(Pitch.COMPRESSED, false, false, false, false);
			pos.addTextData("0        1         2         3         4         5     5".getBytes());
			pos.addFeedLine();
			pos.addTextData("12 4 6 8 0 2 4 6 8 0 2 4 6 8 0 2 4 6 8 0 2 4 6 8 0 2 4 6".getBytes());
			pos.addFeedLine();
			pos.addTextData("|        |         |         |         |         |     |".getBytes());
			pos.addFeedLine();
			
			pos.addAlignment(Alignment.Center);
			pos.addPrintMode(Pitch.STANDARD, false, true, false, false);
			pos.addTextData("Double-High".getBytes());
			pos.addFeedLine();
			
			pos.addAlignment(Alignment.Center);
			pos.addPrintMode(Pitch.STANDARD, false, false, true, false);
			pos.addTextData("Double-Wide".getBytes());
			pos.addFeedLine();
			
			pos.addAlignment(Alignment.Center);
			pos.addPrintMode(Pitch.STANDARD, false, true, true, false);
			pos.addTextData("Both High and Wide".getBytes());
			pos.addFeedLine();
			pos.addFeedLine();
			pos.addFeedLine();
			
			pos.addPrintMode(Pitch.STANDARD, false, false, false, false);
			pos.addAlignment(Alignment.Center);
			pos.addTextItalic(true);
			pos.addTextData("Italic Text".getBytes());
			pos.addTextItalic(false);
			pos.addFeedLine();
			
			pos.addAlignment(Alignment.Center);
			pos.addTextEmphasized(true);
			pos.addTextData("Bold Text".getBytes());
			pos.addFeedLine();
			pos.addTextEmphasized(false);
			
			pos.addAlignment(Alignment.Center);
			pos.addTextUnderline(true);
			pos.addTextData("Underlined Text".getBytes());
			pos.addFeedLine();
			pos.addTextUnderline(false);
			
			pos.addAlignment(Alignment.Center);
			pos.addTextInvertColor(true);
			pos.addTextEmphasized(true);
			pos.addTextData("Reverse Video Text".getBytes());
			pos.addTextInvertColor(false);
			pos.addTextEmphasized(false);
			pos.addFeedLine();
			
			pos.addAlignment(Alignment.Center);
			pos.addTextData("You ".getBytes());
			pos.addTextItalic(true);
			pos.addTextData("can ".getBytes());
			pos.addTextEmphasized(true);
			pos.addTextData("mix ".getBytes());
			pos.addTextUnderline(true);
			pos.addTextData("features ".getBytes());
			pos.addTextInvertColor(true);
			pos.addTextData("too!".getBytes());
			pos.addTextItalic(false);
			pos.addTextEmphasized(false);
			pos.addTextUnderline(false);
			pos.addTextInvertColor(false);
			pos.addFeedLine();
			pos.addFeedLine();
			pos.addFeedLine();
			
			pos.addAlignment(Alignment.Center);
			pos.addQRCode(Model.Model2,5,CorrectionLevelOption.Low,"QR Code by CognitiveTPG".getBytes());
			Byte[] cmd={0x0D,0x0A};
			pos.addCommand(cmd);
			pos.addData("For more information please visit us at:".getBytes());
			pos.addCommand(cmd);
			pos.addData("http://www.cognitivetpg.com/gettheinsidestory".getBytes());
			pos.printQRCode();
			pos.addFeedLine();
			pos.addFeedLine();
			
			pos.addAlignment(Alignment.Center);
			pos.addPrintMode(Pitch.COMPRESSED, false, false, false, false);
			pos.addTextData("QR Code by CognitiveTPG\r\n".getBytes());
			pos.addTextData("For more information please visit us at:\r\n".getBytes());
			pos.addTextData("http://www.cognitivetpg.com/gettheinsidestory\r\n".getBytes());
			pos.addFeedLines(10);
			pos.addCut(CutType.PARTIAL_CUT);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				try 
				{
					BluetoothActivity.printer.sendCommand(pos);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(pos);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private void sendToPrinter(final POSPrinterIO buffer)
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					WiFiActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
		thread.start();
	}
	
	private void printReceipt3()
	{
		try 
		{
			Bitmap bmp=BitmapFactory.decodeStream(getAssets().open("logo.png"));
			BitmapConvertor convert=new BitmapConvertor();
			byte[] image=convert.getMonochromeBitmap(bmp);
			
			POSPrinterIO pos=new POSPrinterIO();
			pos.addInitializePrinter();
			pos.addLogo(image);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				try 
				{
					BluetoothActivity.printer.sendCommand(pos);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(pos);
			}
			
			Thread.sleep(100L);
			
			pos.clearBuffer();
			pos.addAlignment(Alignment.Center);
			pos.printLogo(PrintMode.Quadruple);
			pos.addFeedLines(1);
			
			pos.addAlignment(Alignment.Center);
			pos.addTextData("A799 Receipt\r\n".getBytes());
			pos.addTextData("12-12-2014  13:56:25\r\n".getBytes());
			pos.addTextData("Store # 195\r\n".getBytes());
			pos.addFeedLines(1);
			
			pos.addAlignment(Alignment.Right);
			pos.addTextData(" Thermal Blanket \u0009         14.99\r\n".getBytes());
			pos.addTextData(" 5-Pack Video Tapes \u0009          9.47\r\n".getBytes());
			pos.addTextData(" Hi-Lo Food Processor \u0009         42.95\r\n".getBytes());
			pos.addTextData(" Car Care Cleaning Kit \u0009         28.95\r\n".getBytes());
			pos.addFeedLines(2);
			
			pos.addAlignment(Alignment.Right);
			pos.addTextData(" Subtotal         96.36\r\n".getBytes());
			pos.addTextData(" Sales Tax          7.71\r\n".getBytes());
			pos.addTextData(" Total        104.07\r\n".getBytes());
			pos.addTextData(" Amount Tendered        104.07\r\n".getBytes());
			pos.addTextData(" Change          0.00\r\n".getBytes());
			pos.addFeedLines(3);
			
			pos.addAlignment(Alignment.Center);
			pos.addBarcode(80, BarcodeWide.Wide_2, HRI.HRI_Below, BarCodeType.UPC_A, "036000241457".getBytes());
			pos.addFeedLines(1);
			pos.addBarcode(80, BarcodeWide.Wide_6, HRI.HRI_Below, BarCodeType.Code_39, "123".getBytes());
			pos.addFeedLines(1);
			
			pos.addAlignment(Alignment.Center);
			pos.addTextData(" * *\u0009\u0009Thank You\u0009\u0009* *\r\n".getBytes());
			pos.addTextData(" * *\u0009\u0009Customer Copy\u0009\u0009* *\r\n".getBytes());
			pos.addTextData(" * *\u0009Save Receipt for Returns\u0009* *\r\n".getBytes());
			pos.addFeedLines(6);
			pos.addCut(CutType.PARTIAL_CUT);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				try 
				{
					BluetoothActivity.printer.sendCommand(pos);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(pos);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private void printReceipt4()
	{
		try 
		{
			POSPrinterIO pos=new POSPrinterIO();
			pos.addInitializePrinter();
			pos.addAlignment(Alignment.Center);
			pos.addTextEmphasized(true);
			pos.addTextData("CognitiveTPG\r\n".getBytes());
			pos.addTextData("950 Danby Road\r\n".getBytes());
			pos.addTextData("Suite 200\r\n".getBytes());
			pos.addTextData("Ithaca\r\n".getBytes());
			pos.addTextData("New York\r\n".getBytes());
			pos.addTextData("14850\r\n".getBytes());
			pos.addTextEmphasized(false);
			pos.addFeedLines(1);
			
			pos.addAlignment(Alignment.Left);
			pos.addTextData(" ACCOUNT NO        -->     01234567890\r\n".getBytes());
			pos.addFeedLines(1);
			pos.addTextData(" CURRENT BALANCE   -->     $15000\r\n".getBytes());
			pos.addFeedLines(1);
			pos.addTextData(" PHONE\r\n".getBytes());
			pos.addTextData("   9095430018\r\n".getBytes());
			pos.addTextData(" FAX\r\n".getBytes());
			pos.addTextData("   9095430018\r\n".getBytes());
			pos.addFeedLines(1);
			pos.addTextData(" : HAVE A NICE DAY :\r\n".getBytes());
			pos.addFeedLines(1);
			pos.addTextData("------------------------------\r\n".getBytes());
			pos.addTextData("CHECK PRINT QUALITY ON RECEIPT\r\n".getBytes());
			pos.addTextData("------------------------------\r\n".getBytes());
			pos.addFeedLines(6);
			pos.addCut(CutType.PARTIAL_CUT);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				try 
				{
					BluetoothActivity.printer.sendCommand(pos);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(pos);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private void printReceipt5()
	{
		try 
		{
			SimpleDateFormat format=new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
			//Bitmap bmp=BitmapFactory.decodeStream(getAssets().open("logo.png"));
			//BitmapConvertor convert=new BitmapConvertor();
			//byte[] image=convert.getMonochromeBitmap(bmp);
			byte[] image=getBinaryImage();
			POSPrinterIO pos=new POSPrinterIO();
			pos.addInitializePrinter();
			pos.addLogo(image);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				try 
				{
					BluetoothActivity.printer.sendCommand(pos);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(pos);
			}
			
			Thread.sleep(100L);
			
			pos.clearBuffer();
			pos.addAlignment(Alignment.Center);
			pos.printLogo(PrintMode.Normal);
			pos.addFeedLine();
			pos.addFeedLine();
			
			pos.addPrintMode(Pitch.STANDARD, false, true, true, false);
			pos.addTextData("A799".getBytes());
			pos.addFeedLine();
			pos.addFeedLine();
			pos.addTextData("Thermal Printer".getBytes());
			pos.addFeedLine();
			pos.addFeedLine();
			pos.addPrintMode(Pitch.STANDARD, false, false, false, false);
			
			pos.addAlignment(Alignment.Center);
			pos.addTextData((format.format(new Date())+" Store 522").getBytes());
			pos.addFeedLine();
			pos.addTextData("Cust 177 Reg 10 OPR 165".getBytes());
			pos.addFeedLine();
			
			pos.addAlignment(Alignment.Left);
			pos.addTextData("Dairy".getBytes());
			pos.addFeedLine();
			pos.addTextData("     ABC Sr Crm 16z                 1.29*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     ABC Vim One Mlk                1.19*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Bryers Pch Mode                0.79*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Bryers Pch Mode                0.79*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Byrne Milk 2%                  1.27*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Byrne Milk 2% LF               1.27*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Crowly Buttrmilk               0.88*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Crwly Ult Crm                  0.79*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Phil Crm Chse                  1.49*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Sorr Mozz Lb                   2.99*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Yoplt Orig Yogrt               2.00*".getBytes());
			pos.addFeedLine();
			
			pos.addTextData("Frozen".getBytes());
			pos.addFeedLine();
			pos.addTextData("     ABC Dtch Veg                   1.39*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     ABC Lemnade 12X                0.88T".getBytes());
			pos.addFeedLine();
			pos.addTextData("     GG Niblets 16z                 1.99T".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Min Maid Rasp Lm               1.29T".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Ore Tatr Tot 2lb               2.59*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Welch's Orchrd                 1.69T".getBytes());
			pos.addFeedLine();
			
			pos.addTextData("Grocery".getBytes());
			pos.addFeedLine();
			pos.addTextData("     ABC Bleach 192Z                1.43T".getBytes());
			pos.addFeedLine();
			pos.addTextData("     ABC Jmbo Towels                0.69T".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Baby Carrots                   1.69*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Bananas                        1.01*".getBytes());
			pos.addFeedLine();
			pos.addTextData("         2.15 lb @ 1/1.29".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Bulk - net                     1.99*".getBytes());
			pos.addFeedLine();
			pos.addTextData("         .32 LB @ 1/2.98".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Chiqta Pine Quava              2.49*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Fl Nat Orange Jc               4.18*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Fnst Cntry Adv                 5.88".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Hfty Cnch 20ct                 3.28T".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Kblr Chp Dlx Chc               3.28*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Lettuce                        0.49*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Nrthrn Bath 12pk               3.68T".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Nutri Grain Bar                2.50*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     OS Cranberry 64Z               3.58T".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Pills Rdy Pie Cr               2.29*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Pills Rolls                    2.19*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Polar Club Soda                0.50T".getBytes());
			pos.addFeedLine();
			pos.addTextData("          Deposit                   0.05*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     R Gold Prtzl FF                1.50*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Raid Wasp/Hornet               4.28T".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Rcarni Noodle                  3.20*".getBytes());
			pos.addFeedLine();
			pos.addTextData("          1 @ 2/1.00".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Salt Potatoes                  2.99*".getBytes());
			pos.addFeedLine();
			
			pos.addTextData("Meat/Deli".getBytes());
			pos.addFeedLine();
			pos.addTextData("     ABC NY Shp Colp                3.19*".getBytes());
			pos.addFeedLine();
			pos.addTextData("          1 @ 2/3.00".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Bf Srln Tip Grnd               2.71*".getBytes());
			pos.addFeedLine();
			pos.addTextData("          1 @ 2/5.00".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Bnls Pork Chop                 5.79*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Breast Filets                  3.06*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Genoa Salami                   1.29*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Ground Turkey                  3.74*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Hygrd Meat Ht Dg               1.19*".getBytes());
			pos.addFeedLine();
			pos.addTextData("          3 @ 3/2.00".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Lean Grnd Beef                 3.64*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     OS May Bacon                   3.69*".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Turkey Breast                  2.29*".getBytes());
			pos.addFeedLine();
			
			pos.addTextItalic(true);
			pos.addTextData("Coupons".getBytes());
			pos.addFeedLine();
			pos.addTextData("     VCP                            0.25".getBytes());
			pos.addFeedLine();
			pos.addTextData("     VCP Bonus                      0.25".getBytes());
			pos.addFeedLine();
			pos.addTextData("     VCP                            0.30".getBytes());
			pos.addFeedLine();
			pos.addTextData("     VCP Bonus                      0.30".getBytes());
			pos.addFeedLine();
			pos.addTextData("     VCP                            0.30".getBytes());
			pos.addFeedLine();
			pos.addTextData("     VCP Bonus                      0.30".getBytes());
			pos.addFeedLine();
			pos.addFeedLine();
			pos.addTextItalic(false);
			
			pos.addTextEmphasized(true);
			pos.addTextData("     Subtotal                     109.61".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Chck Tnd                     109.61".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Subtotal                     105.61".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Tax Paid                       3.65".getBytes());
			pos.addFeedLine();
			pos.addTextData("     Change                         0.00".getBytes());
			pos.addFeedLine();
			pos.addFeedLine();
			pos.addFeedLine();
			pos.addTextEmphasized(false);
			
			pos.addTextData("     Order Summary".getBytes());
			pos.addFeedLine();
			pos.addTextData("     48 Items                     105.61".getBytes());
			pos.addFeedLine();
			pos.addTextData("     VCPN Tend                      0.85".getBytes());
			pos.addFeedLine();
			pos.addTextItalic(true);
			pos.addTextData("     Bonus Tend                     0.85".getBytes());
			pos.addTextItalic(false);
			pos.addFeedLine();
			pos.addTextData("     Coupon Total                   1.70".getBytes());
			pos.addFeedLine();
			pos.addFeedLine();
			
			pos.addAlignment(Alignment.Center);
			pos.addTextInvertColor(true);
			pos.addTextEmphasized(true);
			pos.addTextData("You saved $1.70 with Double Coupons today!".getBytes());
			pos.addTextInvertColor(false);
			pos.addTextEmphasized(false);
			pos.addFeedLine();
			pos.addFeedLine();
			
			pos.addTextData("     Thank you for shopping ABC Stores   ".getBytes());
			pos.addFeedLine();
			pos.addTextData("     We save you more!!!".getBytes());
			pos.addFeedLine();
			pos.addFeedLine();
			pos.addFeedLine();
			pos.addBarcode(50, BarcodeWide.Wide_2, HRI.HRI_Below, BarCodeType.Code_128, "234560".getBytes());
			pos.addFeedLines(10);
			pos.addCut(CutType.PARTIAL_CUT);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				try 
				{
					BluetoothActivity.printer.sendCommand(pos);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(pos);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(ReceiptActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
}
