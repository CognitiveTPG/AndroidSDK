package com.ui.ctpgapp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.cognitive.printer.io.POSPrinterIO;
import com.cognitive.printer.io.POSPrinterIO.Alignment;
import com.cognitive.printer.io.POSPrinterIO.PrintMode;

public class ImageActivity extends Activity
{

	private Spinner select_type;
	private FrameLayout print_button;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.image_printing);
		
		select_type=(Spinner) findViewById(R.id.select_type);
		SpinnerAdapter ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new String[] {"PNG", "JPG", "GIF"});
		select_type.setAdapter(ad);
		
		print_button=(FrameLayout) findViewById(R.id.print_button);
		print_button.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View arg0) 
			{
				try 
				{
					//Bitmap bmp=BitmapFactory.decodeStream(getAssets().open("logo.png"));
					//BitmapConvertor convert=new BitmapConvertor();
					//byte[] image=convert.getMonochromeBitmap(bmp);
					
					byte[] image=getBinaryImage();
					
					POSPrinterIO buffer=new POSPrinterIO();
					buffer.addInitializePrinter();
					buffer.addAlignment(Alignment.Center);
					buffer.addLogo(image);
					
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						BluetoothActivity.printer.sendCommand(buffer);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						sendToPrinter(buffer);
					}
					
					Thread.sleep(100L);
					
					buffer.clearBuffer();
					buffer.printLogo(PrintMode.Normal);
					
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						BluetoothActivity.printer.sendCommand(buffer);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						sendToPrinter(buffer);
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
	}
	
	private void sendToPrinter(final POSPrinterIO buffer)
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					WiFiActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
		thread.start();
	}
	
	private byte[] getBinaryImage()
	{
		try 
		{
			InputStream is=getAssets().open("logo.bmp");
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();

			int nRead;
			byte[] data = new byte[16384];

			while ((nRead = is.read(data, 0, data.length)) != -1) {
			  buffer.write(data, 0, nRead);
			}

			buffer.flush();

			return buffer.toByteArray();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(ImageActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
}
