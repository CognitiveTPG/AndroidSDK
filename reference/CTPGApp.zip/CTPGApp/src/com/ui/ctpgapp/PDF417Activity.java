package com.ui.ctpgapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.cognitive.printer.io.POSPrinterIO;
import com.cognitive.printer.io.POSPrinterIO.Alignment;
import com.cognitive.printer.io.POSPrinterIO.BarCodeType;
import com.cognitive.printer.io.POSPrinterIO.BarcodeWide;
import com.cognitive.printer.io.POSPrinterIO.HRI;

public class PDF417Activity extends Activity
{

	private Button print_button;
	private boolean isProcessing=false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pdf417_printing);
		print_button=(Button) findViewById(R.id.btn_print);
		print_button.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View v) 
			{
				try 
				{	
					if(isProcessing)
					{
						return;
					}
					isProcessing=true;
					
					POSPrinterIO buffer=new POSPrinterIO();
					buffer.addResetPrinter();
					buffer.addAlignment(Alignment.Center);
					buffer.addBarcode(216, BarcodeWide.Wide_2, HRI.HRI_Below, BarCodeType.PDF417, "CognitiveTPG".getBytes());
					buffer.addFeedLines(2);
					//buffer.addTone();
					
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						BluetoothActivity.printer.sendCommand(buffer);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						sendToPrinter(buffer);
					}
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
				isProcessing=false;
			}
		});
	}
	
	private void sendToPrinter(final POSPrinterIO buffer)
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					WiFiActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
		thread.start();
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(PDF417Activity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
}
