package com.ui.ctpgapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cognitive.printer.io.POSPrinterIO;
import com.cognitive.printer.io.POSPrinterIO.Alignment;

public class TextActivity extends Activity
{
	private boolean italics=false;
	private boolean upsidedown=false;
	private boolean reverse=false;
	private boolean clock=false;
	private boolean anticlock=false;
	
	private EditText text_data;
	
	private TextView select_italics;
	private TextView select_updown;
	private TextView select_reverse;
	private TextView select_clock;
	private TextView select_counter_clock;
	private static final int NONE=0;
	private static final int CLOCK_WISE=1;
	private static final int ANTI_CLOCKWISE=-1;
	private static  int DIRECTION=NONE;
	
	
	private FrameLayout print_button;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.text_printing);
		text_data=(EditText) findViewById(R.id.text_data);
		
		select_italics=(TextView) findViewById(R.id.select_italics);
		select_italics.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View arg0) 
			{
				if(italics)
				{
					select_italics.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.italics_off, 0, 0);
					italics=false;
				}
				else
				{
					select_italics.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.italics_on, 0, 0);
					italics=true;
				}
			}
		});
		
		select_updown=(TextView) findViewById(R.id.select_updown);
		select_updown.setOnClickListener(new OnClickListener() 
		{
			
			public void onClick(View arg0) 
			{
				if(upsidedown)
				{
					select_updown.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.circle_off, 0, 0);
					upsidedown=false;
				}
				else
				{
					select_updown.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.circle_on, 0, 0);
					upsidedown=true;
				}
			}
		});
		
		select_reverse=(TextView) findViewById(R.id.select_reverse);
		select_reverse.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View arg0) 
			{
				if(reverse)
				{
					select_reverse.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.inverse_off, 0, 0);
					reverse=false;
				}
				else
				{
					select_reverse.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.inverse_on, 0, 0);
					reverse=true;
				}
			}
		});
		
		select_clock=(TextView) findViewById(R.id.select_clock);
		
		select_clock.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View arg0) 
			{
				if(DIRECTION==NONE)
				{
					select_clock.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.clock_on, 0, 0);
					clock=true;
					DIRECTION= CLOCK_WISE;
				}
				else
				if(DIRECTION==CLOCK_WISE)
				{
					select_clock.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.clock_off, 0, 0);
					clock=false;
					DIRECTION= NONE;
				}
				else
				{
					select_clock.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.clock_on, 0, 0);
					select_counter_clock.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.anticlock_off, 0, 0);
					clock=true;
					anticlock=false;
					DIRECTION= CLOCK_WISE;
				}
				
			}
		});
		select_counter_clock=(TextView) findViewById(R.id.select_counter);

		select_counter_clock.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View arg0) 
			{
				if(DIRECTION==NONE)
				{
					select_counter_clock.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.anticlock_on, 0, 0);
					anticlock=true;
					DIRECTION= ANTI_CLOCKWISE;
				}
				else if(DIRECTION==ANTI_CLOCKWISE)
				{
					select_counter_clock.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.anticlock_off, 0, 0);
					anticlock=false;
					DIRECTION= NONE;
				}
				else
				{
					select_counter_clock.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.anticlock_on, 0, 0);
					select_clock.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.clock_off, 0, 0);
					anticlock=true;
					clock=false;
					DIRECTION= ANTI_CLOCKWISE;
				}
			}
		});
		print_button=(FrameLayout) findViewById(R.id.print_button);
		print_button.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View arg0) 
			{
				POSPrinterIO buffer=new POSPrinterIO();
				
				buffer.addInitializePrinter();
				buffer.addAlignment(Alignment.Center);
				buffer.addTextItalic(italics);
				buffer.addTextUpsideDown(upsidedown);
				buffer.addTextInvertColor(reverse);
				buffer.addTextRotation(clock);
				if(anticlock)
				buffer.addTextCounterClockwise();
				
				byte[] data=(text_data.getText().toString()+"\r\n").getBytes();
				buffer.addTextData(data);
				
				if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
				{
					try 
					{
						BluetoothActivity.printer.sendCommand(buffer);
					} 
					catch (Exception e) 
					{
						e.printStackTrace();
					}
				}
				else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
				{
					sendToPrinter(buffer);
				}
			}
		});
	}
	
	private void sendToPrinter(final POSPrinterIO buffer)
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					WiFiActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
		thread.start();
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(TextActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		DIRECTION=NONE;
	}
}
