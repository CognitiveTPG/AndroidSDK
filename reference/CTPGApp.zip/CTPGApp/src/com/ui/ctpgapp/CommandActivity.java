package com.ui.ctpgapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CommandActivity extends Activity
{
	public final String Addr_A798="00:06:66:66:F8:54";
	public final String Addr_A799="00:06:66:66:F0:89";
	public final String Addr_DLXi="00:06:66:66:F8:4F";
	
	private TextView status;
	private EditText command_data;
	private EditText params_data;
	private Button send_button;
	
	private Button history_button;
	private Database database;
	private ArrayList<String> cmdList=new ArrayList<String>();
	
	private boolean isProcess=false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.direct_printing);
		status=(TextView) findViewById(R.id.status);
		status.setText("");
		command_data=(EditText) findViewById(R.id.command_data);
		params_data=(EditText) findViewById(R.id.params_data);
		send_button=(Button) findViewById(R.id.send_button);
		send_button.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				if(isProcess)
				{
					return;
				}
				isProcess=true;
				final String hex=command_data.getText().toString().trim();
				if(!isHexCommand(hex))
				{
//					showToast("Enter Hex Command");
					updateStatus("Enter Hex Command");
					isProcess=false;
					return;
				}
				
				final String command=hex.replace(" ", "");
				
				if(command.length()==0)
				{
//					showToast("Enter Printer Command.");
					updateStatus("Enter Printer Command.");
					isProcess=false;
					return;
				}
				
				Thread thread=new Thread(new Runnable() 
				{
					public void run() 
					{
						try 
						{
							byte[] cmd=hexStringToByteArray(command);
//							byte[] params=getParams();
							
							if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
							{
								BluetoothActivity.connection.writeData(cmd, 0, cmd.length);
							}
							else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
							{
								WiFiActivity.connection.writeData(cmd, 0, cmd.length);
							}
							
							if(!isExists(hex))
							{
								saveCommand(hex);
							}
							
//							if(params!=null)
//							{
//								if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
//								{
//									BluetoothActivity.connection.writeData(params, 0, params.length);
//								}
//								else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
//								{
//									WiFiActivity.connection.writeData(params, 0, params.length);
//								}
//							}
//							
							Thread.sleep(100L);
							updateStatus("Sent");
							
							byte[] read=new byte[100];
							
							int size=0;
							if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
							{
								BluetoothActivity.connection.readData(read, 0, read.length);
							}
							else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
							{
								WiFiActivity.connection.readData(read, 0, read.length);
							}
							
							if(size==1)
							{
								byte statusByte=read[0];
								String str = String.format("%8s", Integer.toBinaryString(statusByte & 0xFF)).replace(' ', '0');
								updateStatus("Printer Response: "+statusByte+" ("+str+")");
							}
							else if(size>1)
							{
								String str=new String(read, 0, size);
								updateStatus("Printer Response: "+str);
							}
						} 
						catch (Exception e) 
						{
							e.printStackTrace();
							updateStatus("Failed to Send");
						}
						isProcess=false;
					}
				});
				thread.start();
			}
		});
		       
		history_button=(Button) findViewById(R.id.history_button);
		history_button.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View v) 
			{
				int numberOfCommands= getCommandSize();
				if(numberOfCommands>=1)
				showDialog();
				else
				showToast("History Empty");
			}
		});
		
		database=new Database(this);
		getCommandList();
	}
	
	private void updateStatus(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				status.setText(msg);
			}
		});
	}
	
	private boolean isHexCommand(String cmd)
	{
		Pattern pattern = Pattern.compile("([0-9A-Fa-f]{2}[ ]){0,31}([0-9A-Fa-f]{2})");
		Matcher match=pattern.matcher(cmd);
		return match.matches();
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(CommandActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	
	private void getCommandList()
	{
		database.openDB();
		cmdList=database.getCommandList();
		database.closeDB();
		System.out.println("Cmd Size "+cmdList.size());
	}
	private int getCommandSize()
	{
		database.openDB();
		cmdList=database.getCommandList();
		database.closeDB();
		return cmdList.size();
	}
	
	
	private boolean isExists(String cmd)
	{
		getCommandList();
		return cmdList.contains(cmd);
	}
	
	private void saveCommand(final String cmd)
	{
		database.openDB();
		database.addCommand(cmd);
		database.closeDB();
	}
	
	private void showDialog()
	{
		getCommandList();
		Collections.reverse(cmdList);
		final String[] items = cmdList.toArray(new String[cmdList.size()]);
		
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pick a Command");
        builder.setItems(items, new DialogInterface.OnClickListener() 
        {
            public void onClick(DialogInterface dialog, int item) 
            {
            	String cmd=items[item];
            	command_data.setText(cmd);
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
	}
	
	public byte[] getParams()
	{
		try 
		{
			String[] param=params_data.getText().toString().trim().split(",");
			byte[] params=new byte[param.length];
			for(int i=0;i<param.length;i++)
			{
				params[i]=(byte) Integer.parseInt(param[i]);
			}
			return params;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public static byte[] hexStringToByteArray(String s) 
	{
        int len = s.length();
        byte[] data = new byte[len/2];

        for(int i = 0; i < len; i+=2)
        {
            data[i/2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i+1), 16));
        }

        return data;
    }
	
	@Override
	protected void onDestroy() 
	{
		super.onDestroy();
	}
	
}
