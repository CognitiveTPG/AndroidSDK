package com.ui.ctpgapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class SplashActivity extends Activity
{
	private Handler handler=new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_screen);
		handler.postDelayed(new Runnable() 
		{
			public void run() 
			{
				finish();
				Intent intent=new Intent(SplashActivity.this, HomeActivity.class);
				startActivity(intent);
			}
		}, 2000);
	}
	
}
