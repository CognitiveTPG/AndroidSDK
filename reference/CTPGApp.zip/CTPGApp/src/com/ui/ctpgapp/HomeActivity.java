package com.ui.ctpgapp;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class HomeActivity extends Activity
{
	private ImageView menu1;
	private ImageView menu2;
	private ImageView menu3;
	
	public static int MODE_CONNECTION=0;
	public static int MODE_WIFI=1;
	public static int MODE_BLUETOOTH=2;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home_screen);

		menu1=(ImageView) findViewById(R.id.menu1);
		menu1.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				if(MODE_CONNECTION==MODE_WIFI)
				{
					
					if(WiFiActivity.connection!=null)
					{
						Intent intent=new Intent(HomeActivity.this, MainActivity.class);
						startActivity(intent);
					}
					else
					{
						showToast("No Printer Connected!");
					}
				}
				else if(MODE_CONNECTION==MODE_BLUETOOTH)
				{
					if(BluetoothActivity.connection!=null)
					{
						Intent intent=new Intent(HomeActivity.this, MainActivity.class);
						startActivity(intent);
					}
					else
					{
						showToast("No Printer Connected!");
					}
				}
				else
				{
					showToast("No Printer Connected!");
				}
			}
		});
		menu2=(ImageView) findViewById(R.id.menu2);
		menu2.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				if(WiFiActivity.isConnectedToWifi)
				{
					MODE_CONNECTION=MODE_WIFI;
	            	Intent intent=new Intent(HomeActivity.this, WiFiActivity.class);
	 				startActivity(intent);
				}
				else
				showDialog();
			}
		});
		menu3=(ImageView) findViewById(R.id.menu3);
		menu3.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				Intent intent=new Intent(HomeActivity.this, AboutActivity.class);
				startActivity(intent);
			}
		});
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(HomeActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	
	public void showDialog() 
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
	    builder.setTitle("Connection Type")
	    .setItems(new String[]{"WiFi","Bluetooth"}, new DialogInterface.OnClickListener() 
	    {
	    	public void onClick(DialogInterface dialog, int which) 
	        {
	    		 dialog.dismiss();
	             if(which==0)
	             {
	            	MODE_CONNECTION=MODE_WIFI;
	            	Intent intent=new Intent(HomeActivity.this, WiFiActivity.class);
	 				startActivity(intent);
	             }
	             else if(which==1)
	             {
	            	 MODE_CONNECTION=MODE_BLUETOOTH;
	            	Intent intent=new Intent(HomeActivity.this, BluetoothActivity.class);
	 				startActivity(intent);
	             }
	        }
	    });
	    builder.create().show();
	}
	@Override
	protected void onResume() {
		super.onResume();
	

	}
	
}
