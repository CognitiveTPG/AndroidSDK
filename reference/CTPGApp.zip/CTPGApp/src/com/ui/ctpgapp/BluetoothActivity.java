package com.ui.ctpgapp;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.cognitive.connection.ConnectionListener;
import com.cognitive.connection.ConnectionManager;
import com.cognitive.connection.DevType;
import com.cognitive.connection.Device;
import com.cognitive.printer.PoSPrinter;
import com.cognitive.printer.PrinterFactory;
import com.cognitive.printer.PrinterModel;

public class BluetoothActivity extends Activity implements ConnectionListener
{
	public final String Addr_A798="00:06:66:66:F8:54";
	public final String Addr_A799="00:06:66:66:F0:89";
	public final String Addr_DLXi="00:06:66:66:F8:4F";
	
	private EditText address_field;
	private Button connect_button;
	
	private ListAdapter adapter;
	private ListView printer_list;
	private Button refresh_button;
	
	private ArrayList<Device> list;
	private static String connectedAddress="";
	
	public static ConnectionManager connection;
	public static PoSPrinter printer;
	
	private static String mannual_connect="";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.printer_setup);
		
		printer_list=(ListView) findViewById(R.id.printer_list);
		printer_list.setOnItemClickListener(new OnItemClickListener() 
		{
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3) 
			{
				if(!mannual_connect.equals(""))
				{
					showToast("Disconnect Active Connection");
					return;
				}
				int position=arg2;
				Device dev=list.get(position);
				final String address=dev.getAddress();
				
				if(connectedAddress.equalsIgnoreCase(""))
				{
					Handler handler=new Handler();
					handler.post(new Runnable() 
					{
						public void run() 
						{
							boolean isConnected=connect(address);
							if(isConnected)
								connectedAddress=address;
							else
								connectedAddress="";
						}
					});
				}
				else if(address.equalsIgnoreCase(connectedAddress))
				{
					try 
					{
						if(connection!=null)
						{
							connection.closeConnection();
							connection=null;
							printer=null;
							connectedAddress="";
							adapter.notifyDataSetChanged();
							return;
						}
					} 
					catch (Exception e) 
					{
						e.printStackTrace();
					}
				}
				else
				{
					showToast("Disconnect Active Connection");
				}
			}
		});
		
		refresh_button=(Button) findViewById(R.id.btn_refresh);
		refresh_button.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				try 
				{
					list=ConnectionManager.searchPrinters(DevType.BLUETOOTH,BluetoothActivity.this);
					if(list!=null && list.size()>0)
					{
						adapter=new ListAdapter();
						printer_list.setAdapter(adapter);
					}
					else
					{
						showToast("No Printer Found!");
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
		
		address_field=(EditText) findViewById(R.id.field_address);
		address_field.setText(mannual_connect);
		connect_button=(Button) findViewById(R.id.btn_connect);
		connect_button.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				if(!connectedAddress.equalsIgnoreCase(""))
				{
					showToast("Disconnect Active Connection");
					return;
				}
				if(connect_button.getId()==0)
				{
					String address=address_field.getText().toString().trim();
					if(address.length()==0)
					{
						showToast("Enter Mac Address");
						return;
					}
					boolean isConnected=connect(address);
					if(isConnected)
					{
						mannual_connect=address;
						connect_button.setId(1);
						connect_button.setText("Disconnect");
					}
					return;
				}
				if(connect_button.getId()==1)
				{
					try 
					{
						if(connection!=null)
						{
							connection.closeConnection();
							connect_button.setId(0);
							connect_button.setText("Connect");
							connection=null;
							printer=null;
							mannual_connect="";
							return;
						}
					} 
					catch (Exception e) 
					{
						e.printStackTrace();
					}
					return;
				}
			}
		});
		
		refresh_button.performClick();
		if(mannual_connect.equalsIgnoreCase(""))
		{
			connect_button.setId(0);
			connect_button.setText("Connect");
		}
		else
		{
			connect_button.setId(1);
			connect_button.setText("Disconnect");
		}
	}
	
	
	
	private class ListAdapter extends BaseAdapter
	{

		@Override
		public int getCount() 
		{
			return list.size();
		}

		@Override
		public Object getItem(int arg0) 
		{
			return arg0;
		}

		@Override
		public long getItemId(int arg0) 
		{
			return arg0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) 
		{
			ViewHolder holder;
			if(convertView==null)
			{
				holder=new ViewHolder();
				LayoutInflater li = getLayoutInflater();
				convertView = li.inflate(R.layout.list_item, null);
				holder=new ViewHolder();
				holder.image=(ImageView) convertView.findViewById(R.id.icon);
				holder.text=(TextView) convertView.findViewById(R.id.text);
				holder.check=(CheckBox) convertView.findViewById(R.id.check);
				convertView.setTag(holder);
			}
			else 
			{
				holder=(ViewHolder)convertView.getTag();
			}
			
			Device dev=list.get(position);
			String name=dev.getName();
			String address=dev.getAddress();
			holder.text.setText(name);
			holder.check.setId(position);
			holder.check.setOnCheckedChangeListener(onCheck);
			
			if(connectedAddress.equalsIgnoreCase(address))
			{
				holder.image.setImageResource(R.drawable.ic_bluetooth_active);
			}
			else
			{
				holder.image.setImageResource(R.drawable.ic_blueooth_inactive);
			}
			return convertView;
		}
	}
	
	CompoundButton.OnCheckedChangeListener onCheck=new CompoundButton.OnCheckedChangeListener() 
	{
		public void onCheckedChanged(final CompoundButton buttonView, boolean isChecked) 
		{
			if(isChecked)
			{
				int position=buttonView.getId();
				Device dev=list.get(position);
				final String address=dev.getAddress();
				
				Handler handler=new Handler();
				handler.post(new Runnable() 
				{
					public void run() 
					{
						boolean isConnected=connect(address);
						if(isConnected)
							connectedAddress=address;
						else
							buttonView.setChecked(false);
					}
				});
			}
		}
	};
	
	private boolean connect(final String address)
	{
		try 
		{
			connection=ConnectionManager.getConnection(DevType.BLUETOOTH);
			connection.setConnectionListener(BluetoothActivity.this);
			connection.openConnection(address);
			
			printer=(PoSPrinter) PrinterFactory.getPrinter(PrinterModel.A799);
			printer.setConnection(connection);
			return true;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			showToast("Connection Error: "+e.getMessage());
			connection=null;
			printer=null;
		}
		return false;
	}
	
	static class ViewHolder
	{
		ImageView image;
		TextView text;
		CheckBox check;
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(BluetoothActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	
	@Override
	protected void onDestroy() 
	{
		super.onDestroy();
	}

	@Override
	public void onConnected() 
	{
		showToast("Connected");
		if(adapter!=null)
			adapter.notifyDataSetChanged();
	}

	@Override
	public void onDisconnected() 
	{
		showToast("Disconnected");
		connectedAddress="";
		if(adapter!=null)
			adapter.notifyDataSetChanged();
	}

	@Override
	public void onError(String arg0) 
	{
		showToast("Printer Error: "+arg0);
	}

}
