package com.ui.ctpgapp;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.sax.StartElementListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cognitive.printer.io.POSPrinterIO;
import com.cognitive.printer.io.POSPrinterIO.Alignment;
import com.cognitive.printer.io.POSPrinterIO.BarCodeType;
import com.cognitive.printer.io.POSPrinterIO.BarcodeWide;
import com.cognitive.printer.io.POSPrinterIO.CorrectionLevelOption;
import com.cognitive.printer.io.POSPrinterIO.CutType;
import com.cognitive.printer.io.POSPrinterIO.HRI;
import com.cognitive.printer.io.POSPrinterIO.Model;
import com.cognitive.status.PrinterStatus;

public class MainActivity extends Activity
{
	private String[] label={"Text","Image","Barcode","QR Code","PDF417","Print Sample","Raw I/O","Printer Info","File Print"};
	private int[] icon={R.drawable.icon_text,R.drawable.icon_image,R.drawable.icon_barcode,R.drawable.icon_qrcode,R.drawable.icon_pdf417,R.drawable.icon_receipt,R.drawable.icon_raw,R.drawable.icon_info,R.drawable.icon_file};
	
	private GridAdapter adapter;
	private GridView action_list;
	
	private ImageView close_button;
	
	public static TextView status;
	private TextView tone;
	private TextView test_print;
	private TextView full_cut;
	private TextView partial_cut;
	public static TextView tvConnectedIP;
	//jagan start
	public static RelativeLayout relProgress;
	public static Activity activity;
	//jagan end
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		activity=MainActivity.this;
		close_button=(ImageView) findViewById(R.id.btn_close);
		relProgress=(RelativeLayout)findViewById(R.id.rellayout);
		relProgress.setVisibility(View.GONE);
		tvConnectedIP=(TextView)findViewById(R.id.connection_ip);
		if (WiFiActivity.CONNECTED_PRINTER_IP.equals("")) {
		tvConnectedIP.setText("Sample Printing");
		}else{
		tvConnectedIP.setText("Connected to ip :"+WiFiActivity.CONNECTED_PRINTER_IP);
		}
		close_button.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View v) 
			{
				closeConnection();
				finish();
			}
		});
		
		action_list=(GridView) findViewById(R.id.action_list);
		adapter=new GridAdapter();
		action_list.setAdapter(adapter);
		action_list.setOnItemClickListener(new OnItemClickListener() 
		{
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3) 
			{
				//jagan
				
					
				
				Intent intent=null;
				switch (arg2) 
				{
				case 0:
					
					intent=new Intent(MainActivity.this, TextActivity.class);
					startActivity(intent);
					break;
					
				case 1:
					
					intent=new Intent(MainActivity.this, ImageActivity.class);
					startActivity(intent);
					break;
					
				case 2:
					
					intent=new Intent(MainActivity.this, BarcodeActivity.class);
					startActivity(intent);
					break;
					
				case 3:
					
					printQRCode();
					
					break;
					
				case 4:
					
					printPDF417();
					
					break;
					
				case 5:
					
					intent=new Intent(MainActivity.this, ReceiptActivity.class);
					startActivity(intent);
					break;
					
				case 6:
					
					intent=new Intent(MainActivity.this, CommandActivity.class);
					startActivity(intent);
					break;
					
				case 7:
	
					intent=new Intent(MainActivity.this, PrinterInfoActivity.class);
					startActivity(intent);
					
					break;
					
				case 8:
					
					intent=new Intent(MainActivity.this, FileActivity.class);
					startActivity(intent);
					//chooseFilePicker();
					break;
				}
			}
		});
		
		status=(TextView) findViewById(R.id.status);
//		status.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, R.drawable.ic_status);
		status.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View v) 
			{
				//jagan
				
				Thread thread=new Thread(new Runnable() 
				{
					public void run() 
					{
						try 
						{
							PrinterStatus ps=null;
							if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
							{
								ps=BluetoothActivity.printer.getStatus();
							}
							else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
							{
								ps=WiFiActivity.printer.getStatus();
							}
							
							if(ps.isPaperLow())
							{
								showToast("Receipt Paper: Low");
							}
							if(ps.isCoverOpen())
							{
								showToast("Receipt Cover: Open");
							}
							if(!ps.isKnifeHomePosition())
							{
								showToast("Knife Position: Not Home Position");
							}
							if(!ps.isPaperPresent())
							{
								showToast("Receipt Paper: Out");
							}
							if(ps.isTemperatureOK())
							{
								showToast("Temperature: In Valid Range");
							}
							if(ps.isVoltageOK())
							{
								showToast("Voltage: In Valid Range");
							}
						}
						catch (Exception e) 
						{
							e.printStackTrace();
							showToast("Printer Error");
						}
					}
				});
				thread.start();
			}
		});
		
		tone=(TextView) findViewById(R.id.tone);
		tone.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View v) 
			{
				//jagan
				
				try 
				{
					POSPrinterIO buffer=new POSPrinterIO();
					buffer.addResetPrinter();
					buffer.addTone();
					
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						BluetoothActivity.printer.sendCommand(buffer);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						sendToPrinter(buffer);
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Beep");
				}
			}
		});
		
		test_print=(TextView) findViewById(R.id.test_print);
		test_print.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View v) 
			{//jagan
				
				try 
				{
					POSPrinterIO buffer=new POSPrinterIO();
					buffer.addInitializePrinter();
					buffer.addTestForm();
					
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						BluetoothActivity.printer.sendCommand(buffer);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						sendToPrinter(buffer);
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
		
		full_cut=(TextView) findViewById(R.id.full_cut);
		full_cut.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View v) 
			{
				//jagan
				
				try 
				{
					POSPrinterIO buffer=new POSPrinterIO();
					buffer.addInitializePrinter();
					buffer.addFeedLines(50);
					buffer.addCut(CutType.FULL_CUT);
					
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						BluetoothActivity.printer.sendCommand(buffer);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						sendToPrinter(buffer);
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Cut");
				}
			}
		});
		
		partial_cut=(TextView) findViewById(R.id.partial_cut);
		partial_cut.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View v) 
			{
				//jagan
			
				try 
				{
					POSPrinterIO buffer=new POSPrinterIO();
					buffer.addInitializePrinter();
					buffer.addFeedLines(50);
					buffer.addCut(CutType.PARTIAL_CUT);
					
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						BluetoothActivity.printer.sendCommand(buffer);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						sendToPrinter(buffer);
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
	}
	
	private void chooseFilePicker()
	{
		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
	    intent.setType("*/*");
	    intent.addCategory(Intent.CATEGORY_OPENABLE);
	    try 
	    {
	        startActivityForResult(Intent.createChooser(intent, "Select A BIN File"),0);
	    } 
	    catch (Exception ex) 
	    {
	    	ex.printStackTrace();
	    	showToast("No Activity Found!!!");
	    }
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) 
		{
			Uri uri = data.getData();
	        String path = uri.getPath();
	        File file = new File(path);
	        sendFile(file);
	        
	    }
		else
		{
			showToast("File Selection Cancelled!!!");
		}
	}
	
	private void sendFile(final File file)
	{
		try 
		{
			InputStream is=new FileInputStream(file);
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();

			int nRead;
			byte[] data = new byte[16384];

			while ((nRead = is.read(data, 0, data.length)) != -1) 
			{
			  buffer.write(data, 0, nRead);
			}
			buffer.flush();
			byte[] binary=buffer.toByteArray();
			
			POSPrinterIO pos=new POSPrinterIO();
			pos.addData(binary);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				BluetoothActivity.printer.sendCommand(pos);
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(pos);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private void printQRCode()
	{
		try 
		{
			POSPrinterIO buffer=new POSPrinterIO();
			buffer.addInitializePrinter();
			buffer.addAlignment(Alignment.Center);
			buffer.addQRCode(Model.Model2,5,CorrectionLevelOption.Low,"QR Code by CognitiveTPG".getBytes());
			Byte[] cmd={0x0D,0x0A};
			buffer.addCommand(cmd);
			buffer.addData("For more information please visit us at:".getBytes());
			buffer.addCommand(cmd);
			buffer.addData("http://www.cognitivetpg.com/gettheinsidestory".getBytes());
			buffer.printQRCode();
			buffer.addFeedLine();
			buffer.addFeedLine();
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				BluetoothActivity.printer.sendCommand(buffer);
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(buffer);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private void printPDF417()
	{
		try 
		{
			POSPrinterIO buffer=new POSPrinterIO();
			buffer.addInitializePrinter();
			buffer.addAlignment(Alignment.Center);
			buffer.addBarcode(216, BarcodeWide.Wide_2, HRI.HRI_Below, BarCodeType.PDF417, "CognitiveTPG".getBytes());
			buffer.addFeedLines(2);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				BluetoothActivity.printer.sendCommand(buffer);
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(buffer);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private void sendToPrinter(final POSPrinterIO buffer)
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					WiFiActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
		thread.start();
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	
	private void closeConnection()
	{
		try 
		{
//			if(PrintersActivity.connection!=null)
//			{
//				PrintersActivity.connection.closeConnection();
//			}
//			PrintersActivity.connection=null;
//			PrintersActivity.printer=null;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private class GridAdapter extends BaseAdapter
	{
		
		public GridAdapter() 
		{
			
		}

		@Override
		public int getCount() 
		{
			// TODO Auto-generated method stub
			return label.length;
		}

		@Override
		public Object getItem(int arg0) 
		{
			// TODO Auto-generated method stub
			return arg0;
		}

		@Override
		public long getItemId(int arg0) 
		{
			// TODO Auto-generated method stub
			return arg0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) 
		{
			
			ViewHolder holder;
			if(convertView==null)
			{
				holder=new ViewHolder();
				LayoutInflater li = getLayoutInflater();
				convertView = li.inflate(R.layout.grid_item, null);
				holder=new ViewHolder();
				holder.imageView=(ImageView) convertView.findViewById(R.id.icon);
				holder.textView=(TextView) convertView.findViewById(R.id.label);
				convertView.setTag(holder);
			}
			else 
			{
				holder=(ViewHolder)convertView.getTag();
			}
			holder.imageView.setImageResource(icon[position]);
			holder.textView.setText(label[position]);
			return convertView;
		}
		
	}
	
	static class ViewHolder
	{
		ImageView imageView;
		TextView textView;
	}
	
	@Override
	protected void onDestroy() 
	{
		super.onDestroy();
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		finish();
	}
	
	
	public static void refreshActivity() {
	
		activity.startActivity(new Intent(activity, MainActivity.class));
	}

}
