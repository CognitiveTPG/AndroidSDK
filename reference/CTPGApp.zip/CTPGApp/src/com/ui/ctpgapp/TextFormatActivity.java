package com.ui.ctpgapp;

import com.cognitive.printer.io.POSPrinterIO;
import com.cognitive.printer.io.POSPrinterIO.Alignment;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

public class TextFormatActivity extends Activity
{

	private EditText text_data;
	
	private CheckBox check_italics;
	private CheckBox check_updown;
	private CheckBox check_reverse;
	private CheckBox check_clock;
	private CheckBox check_counter_clock;
	
	private FrameLayout print_button;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.text_formatting);
		text_data=(EditText) findViewById(R.id.text_data);
		
		check_italics=(CheckBox) findViewById(R.id.check_italics);
		check_updown=(CheckBox) findViewById(R.id.check_updown);
		check_reverse=(CheckBox) findViewById(R.id.check_reverse);
		check_clock=(CheckBox) findViewById(R.id.check_clock);
		check_counter_clock=(CheckBox) findViewById(R.id.check_counter);
		
		print_button=(FrameLayout) findViewById(R.id.print_button);
		print_button.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View arg0) 
			{
				POSPrinterIO buffer=new POSPrinterIO();
				buffer.addInitializePrinter();
				buffer.addAlignment(Alignment.Center);
				buffer.addTextItalic(check_italics.isChecked());
				buffer.addTextUpsideDown(check_updown.isChecked());
				buffer.addTextInvertColor(check_reverse.isChecked());
				buffer.addTextRotation(check_clock.isChecked());
				if(check_counter_clock.isChecked())
					buffer.addTextCounterClockwise();
				byte[] data=(text_data.getText().toString()+"\r\n").getBytes();
				buffer.addTextData(data);
				
				if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
				{
					try 
					{
						BluetoothActivity.printer.sendCommand(buffer);
					} 
					catch (Exception e) 
					{
						e.printStackTrace();
					}
				}
				else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
				{
					sendToPrinter(buffer);
				}
			}
		});
	}
	
	private void sendToPrinter(final POSPrinterIO buffer)
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					WiFiActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
		thread.start();
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(TextFormatActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	
}
