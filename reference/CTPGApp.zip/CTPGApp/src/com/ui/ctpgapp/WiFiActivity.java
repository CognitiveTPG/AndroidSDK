package com.ui.ctpgapp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.cognitive.connection.ConnectionListener;
import com.cognitive.connection.ConnectionManager;
import com.cognitive.connection.DevType;
import com.cognitive.connection.Device;
import com.cognitive.printer.PoSPrinter;
import com.cognitive.printer.PrinterFactory;
import com.cognitive.printer.PrinterModel;

/**
 * This class helps developer to establish connection from Wifi devices to Wired Ethernet printers.
 * This class provide two types of connection <br>
 * 1. Static :- In this type user can connect with printer by providing IP Address of the Printer.<br>
 * 2. By Scanning :- In this method app will discover those Cognitive printer which are connected in the
 * same network in which mobile devices is connected. Whenever user select any devices, that devices will
 * connect to the Printer. 
 * @author Manoj
 *
 */

public class WiFiActivity extends Activity implements ConnectionListener
{
	private EditText address_field;
	private Button connect_button;
	
	private ListAdapter adapter;
	private ListView printer_list;
	private Button refresh_button;
	
	private ArrayList<Device> list=new ArrayList<Device>();
	private static String connectedAddress="";
	
	public static ConnectionManager connection;
	public static PoSPrinter printer;
	public static boolean isManualConnection=false;
	public static boolean  isConnectedToWifi=false;
	private static int START;
	private static int END;
	
//	private static boolean isMannualCoonect=false;
	private static boolean isConnected=false,connectionFirstTime=true;
	public static  boolean isPrinterFoundAtFirstAttempt=true;
	private ProgressDialog dialog;
	private  ScheduledExecutorService scheduleTaskExecutor;
	/**
	 * Pattern for IP Address validation 
	 */
	private static final String PATTERN = 
	        "^(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
	private static final int TIMEOUT=200;
	public static String CONNECTED_PRINTER_IP;
	public Boolean autoDisconnect=true;
	int countCheck=0,disconnectionCountCheck=0;
	Boolean socketconnectionCheck,socketDialogShowCheck;
	public static Activity activity;
//	ArrayList<ScheduledExecutorService> ArryScheduleTaskExecutor=new ArrayList<ScheduledExecutorService>();
	Boolean scheduleTaskExecutorFlag=false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.printer_setup_wifi);
		printer_list=(ListView) findViewById(R.id.printer_list);
		
		address_field=(EditText) findViewById(R.id.field_address);
		
		connect_button=(Button) findViewById(R.id.btn_connect);
		activity=WiFiActivity.this;
		
		if(isConnectedToWifi)
		{
			 address_field.setEnabled(false);
    		 connect_button.setEnabled(false);
    		 //jagan start
    		 Device dev=new Device(CONNECTED_PRINTER_IP, "");
			 list.add(dev);
			 if(list!=null && list.size()>0)
				{
					adapter=new ListAdapter();
					printer_list.setAdapter(adapter);
				}
			 //jagan end
		}else{
			scanPrinters();
		}
		
		printer_list.setOnItemClickListener(new OnItemClickListener() 
		{
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3) 
			{
				int position=arg2;
				Device dev=list.get(position);
				final String address=dev.getName().trim().toString();
				
				Log.i("Address", address);
					
					runOnUiThread(new Runnable() {
					     @Override
					     public void run() {
					    	 
					    	 if(isConnected==false)
					    	 {
					    		 autoDisconnect=true;
//					    		 connectionFirstTime=true;
					    		 connect(address);
					    		 isManualConnection=false;
					    		 address_field.setEnabled(false);
					    		 connect_button.setEnabled(false);
					    		
					    		 
					    	 }
					    	 else
					    	 { 
					    		 autoDisconnect=false;
					    		 disconnect();
					    		 address_field.setEnabled(true);
					    		 connect_button.setEnabled(true);
					    		
					    	 }

					    }
					});
				}
		});
		
		refresh_button=(Button) findViewById(R.id.btn_refresh);
		refresh_button.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				isPrinterFoundAtFirstAttempt=true;
				ScanIPAddress task = new ScanIPAddress();
				task.execute(null,null,null);
			}
		});
		
		
		connect_button.setOnClickListener(new OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				isManualConnection=true;
				if(isConnected==false)
				{
					if(address_field.getText().toString().equalsIgnoreCase(""))
					{
						showToast("Please Enter IP Address !");
					}
					else if(!validate(address_field.getText().toString()))
					{
						showToast("Please Enter a valid IP Address !");
					}
					else
					{
						autoDisconnect=true;
//						connectionFirstTime=true;
						connect(address_field.getText().toString());
					
					}
				}
				else
				{	
					autoDisconnect=false;
					disconnect();
				
//					connect_button.setText("Connect");
				}
			}
		});
		
//		scanPrinters();
		
	}
	 protected void scanPrinters() {
			
			try 
			{
				runOnUiThread(new Runnable() 
				{
					public void run() 
					{
						try {
							list=ConnectionManager.searchPrinters(DevType.TCP,WiFiActivity.this);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
				
				if(list!=null && list.size()>0)
				{
					adapter=new ListAdapter();
					printer_list.setAdapter(adapter);
				}
				else
				{
					showToast("No Printer Found!");
				}
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
	}
	public class ScanIPAddress extends AsyncTask<String, Void, String> {
		  
		@Override
		protected void onPreExecute()
		{
			showProgress();
		}
		    @Override
		    protected String doInBackground(String... urls) 
		    {
		    	try {
		    		
					list=pingPrinters(WiFiActivity.this);
					
				} 
		    	catch (Exception e)
		    	{
					e.printStackTrace();
				}
		    	return null;
		     
		    }

		    @Override
		    protected void onPostExecute(String result)
		    {
		    	hideProgress();
		    	System.out.println("ipAddress: "+"Finished");
		    	if(isManualConnection)
		    	{
		    	 Device dev=new Device(CONNECTED_PRINTER_IP, "");
    			 list.add(dev);
		    	}
		    	/*adapter=new ListAdapter();
				printer_list.setAdapter(adapter);*/
		    	if(list!=null && list.size()>0)
				{
					adapter=new ListAdapter();
					printer_list.setAdapter(adapter);
					
				}
				else
				isPrinterFoundAtFirstAttempt=false;
					
		    	if(isPrinterFoundAtFirstAttempt==false && END==50)
				{
						ScanIPAddress task = new ScanIPAddress();
						task.execute(null,null,null);
						
				}
		    	else 
		    		
		    	{
		    		hideProgress();
		    		if(list.size()==0)
		    		showToast("No Printer Found !");
		    	}
					
		    }
		  }
	protected static ArrayList<Device>  pingPrinters(Context context) throws Exception
	{
		
		ArrayList<Device> list=new ArrayList<Device>();
		WifiManager wifiMgr =(WifiManager) context.getSystemService(Context.WIFI_SERVICE); 
    	WifiInfo wifiInfo = wifiMgr.getConnectionInfo();
    	int ipadd = wifiInfo.getIpAddress();
    	String ipAddress = Formatter.formatIpAddress(ipadd);
    	System.out.println("ipAddress: "+ipAddress);
    	if(isPrinterFoundAtFirstAttempt==false)
    	{
    		START = 51;
    		END   = 255;
    	}
    	else
    	{
    		START = 1;
    		END   = 50;
    	}
    	 for (int i = START; i <= END; i++) 
    	 {
    		 System.out.println("ipAddress: "+ipAddress);
    		 String addr = ipAddress;
    		 addr = addr.substring(0, addr.lastIndexOf('.') + 1) + i;
    		 InetAddress pingAddr = null;
    		 try 
    		 {
    			 
    			 pingAddr = InetAddress.getByName(addr);
    			 System.out.println("ipAddress: "+pingAddr);
    			 if (pingAddr.isReachable(TIMEOUT))
    			 {
    				 System.out.println("ipAddress: "+pingAddr.toString());
    				 boolean isCognitivePrinter= filterCognitivePrinter(pingAddr.toString());
    				 if(isCognitivePrinter)
    				 {
    					 String str= pingAddr.toString();
    					 String finalIPAddress=null;
    					 if(str.contains("/"))
    					 {
    						 finalIPAddress = str.substring(1,str.length());
    					 }
    					 else
    					 {
    						 finalIPAddress = str;
    					 }
    					 Device dev=new Device(finalIPAddress, "");
		    			 list.add(dev);
		    			 continue;
    				 }
    			 }
    		 } 
    		 catch (IOException e) 
    		 {
    			 // TODO Auto-generated catch block
    			 e.printStackTrace();
    		 }
    	 }
		return list;
	}
	private static boolean filterCognitivePrinter(String pingAddress) {
		 StringBuffer echo = new StringBuffer();
		   try {
		     BufferedReader br = new BufferedReader(new FileReader("/proc/net/arp"));
		     String line = "";
		     while((line = br.readLine()) != null) 
		     {	
		    	 String[] tokens = line.split(" +");
		    	 echo.append(line + "\n");
		    	 String finalIPAddress=null;
		    	 if(pingAddress.toString().contains("/"))
		    	 {
		    		 finalIPAddress= pingAddress.substring(1,pingAddress.length());
		    	 }
		    	 else
		    	 {
		    		 finalIPAddress = pingAddress.toString();
		    	 }
		    	 if(tokens[0].equalsIgnoreCase(finalIPAddress))
		    	 {
		    		 String macOctet = tokens[3].substring(0, 8);
//		    		 System.out.println("Mac Address "+macOctet);
		    		 if(macOctet.equalsIgnoreCase("00:E0:70"))
		    		 {
		    			 return true;
		    		 }
		    	 }
		    	 
		   
		     }
		     br.close();
		   }
		     catch (Exception e) {
				e.printStackTrace();
			}
		 
		   return false;
	}
	private void showProgress()
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				dialog=ProgressDialog.show(WiFiActivity.this, "", "Scanning CognitiveTPG Printers...");
			}
		});
	}
	
	private void showProgress(final String message, final Activity contex) {
		contex.runOnUiThread(new Runnable() {
			public void run() {
				try {
					
				
				if (dialog.isShowing()) {

				} else {
					dialog = ProgressDialog.show(contex, "", message, true,
							true, new DialogInterface.OnCancelListener() {
								@Override
								public void onCancel(DialogInterface dialog) {
									finish();
//									stoptimertask();
								}
							});
					dialog.setCanceledOnTouchOutside(false);
				}
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		});
	}
	
	private void hideProgress(Activity contex)
	{
		contex.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				if(dialog!=null)
					dialog.dismiss();
			}
		});
	}
	
	private void hideProgress()
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				if(dialog!=null)
					dialog.dismiss();
			}
		});
	}
	
	public void changeButton(final int id,final String label)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				connect_button.setId(id);
				connect_button.setText(label);
			}
		});
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(WiFiActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	
	private class ListAdapter extends BaseAdapter
	{
		@Override
		public int getCount() 
		{
			return list.size();
		}

		@Override
		public Object getItem(int arg0) 
		{
			return arg0;
		}

		@Override
		public long getItemId(int arg0) 
		{
			return arg0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) 
		{
			ViewHolder holder;
			if(convertView==null)
			{
				holder=new ViewHolder();
				LayoutInflater li = getLayoutInflater();
				convertView = li.inflate(R.layout.list_item, null);
				holder=new ViewHolder();
				holder.image=(ImageView) convertView.findViewById(R.id.icon);
				holder.text=(TextView) convertView.findViewById(R.id.text);
				holder.check=(CheckBox) convertView.findViewById(R.id.check);
				convertView.setTag(holder);
			}
			else 
			{
				holder=(ViewHolder)convertView.getTag();
			}
			
			Device dev=list.get(position);
			String name=dev.getName().trim().toString();;
			String address=dev.getAddress();
			holder.text.setText(name);
			holder.check.setId(position);
			holder.check.setOnCheckedChangeListener(onCheck);
			
			if(connectedAddress.equalsIgnoreCase(name))
			{
				holder.image.setImageResource(R.drawable.wifi_active);
			}
			else
			{
				holder.image.setImageResource(R.drawable.wifi_deactive);
			}
			return convertView;
		}
	}
	
	CompoundButton.OnCheckedChangeListener onCheck=new CompoundButton.OnCheckedChangeListener() 
	{
		public void onCheckedChanged(final CompoundButton buttonView, boolean isChecked) 
		{
			if(isChecked)
			{
				
			}
		}
	};
	
	private void connect(final String address)
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{	
					connection = ConnectionManager.getConnection(DevType.TCP);
					connection.setConnectionListener(WiFiActivity.this);
					CONNECTED_PRINTER_IP = address;
					connection.openConnection(address);
					printer = (PoSPrinter) PrinterFactory.getPrinter(PrinterModel.A799);
					printer.setConnection(connection);
					System.out.println("Connection Success");
					
				
					isConnected = true;
					connectedAddress =address;
					/* for(int i=0;i<=ArryScheduleTaskExecutor.size();i++){
			    		 Log.d("tag", "ArryScheduleTaskExecutor for :"+ArryScheduleTaskExecutor.size());
			    		 ArryScheduleTaskExecutor.get(i).shutdownNow();
			    	 }
			    	 scheduleTaskExecutorFlag=false;
			    	 ArryScheduleTaskExecutor.clear();*/
					printerConnectivityDetector(WiFiActivity.this,CONNECTED_PRINTER_IP);
					runOnUiThread(new Runnable() {
					     @Override
					     public void run() 
					     {
					    	 if(isManualConnection)
					    	 {
					    		
					    		 connect_button.setText("Disconnect");
					    		 //jagan start
					    		 Device dev=new Device(CONNECTED_PRINTER_IP, "");
				    			 list.add(dev);
				    			 if(list!=null && list.size()>0)
				 				{
				 					adapter=new ListAdapter();
				 					printer_list.setAdapter(adapter);
				 				}
				    			 //jagan end
//					    		 scanPrinters();
					    	 }
					    	 isConnectedToWifi=true;
						 }
					    	
					});
					 /*if (connectionFirstTime) {
							reConnection(CONNECTED_PRINTER_IP);
							connectionFirstTime=false;
							return;
						}*/
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					Log.i("tag", "Exception");
					if (e.getMessage().contains("ECONNREFUSED")) {/*
						Log.i("tag", "java.net.ConnectException ");
						printerConnectivityDetector(WiFiActivity.this,CONNECTED_PRINTER_IP);
						CONNECTED_PRINTER_IP = address;
						isConnected = true;
						connectedAddress =address;
						
						runOnUiThread(new Runnable() {
						     @Override
						     public void run() 
						     {
						    	 if(isManualConnection)
						    	 {
						    		
						    		 connect_button.setText("Disconnect");
						    		 //jagan start
						    		 Device dev=new Device(CONNECTED_PRINTER_IP, "");
					    			 list.add(dev);
					    			 if(list!=null && list.size()>0)
					 				{
					 					adapter=new ListAdapter();
					 					printer_list.setAdapter(adapter);
					 					
					 					
					 				}
					    			 //jagan end
//						    		 scanPrinters();
						    	 }
						    	 isConnectedToWifi=true;
						    	  adapter.notifyDataSetChanged();	
							 }
						   
						});
					*/
						Log.i("tag", "java.net.ConnectException ");
					}
					/*showToast("Connection Error: "+e.getMessage());
					connection=null;
					printer=null;*/
				}
			}
		});
		thread.start();
	}
	
	public void disconnect()
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					if(connection!=null)
					{
						runOnUiThread(new Runnable() {
						     @Override
						     public void run() {

						    	 try {
						    		 connection.closeConnection();
									 connection=null;
							    	 printer=null;
							    	 isConnected=false;
							    	 adapter.notifyDataSetChanged();
							    	 if(connect_button.getText().toString().equalsIgnoreCase("Disconnect"))
							    	 connect_button.setText("Connect");
							    	 scanPrinters();
							    	 isConnectedToWifi=false;
							    	 Log.d("tag", "ArryScheduleTaskExecutor :"+HomeActivity.ArryScheduleTaskExecutor.size());
							    	 for(int i=0;i<HomeActivity.ArryScheduleTaskExecutor.size();i++){
							    		 Log.d("tag", "ArryScheduleTaskExecutor for disconnect:"+HomeActivity.ArryScheduleTaskExecutor.size());
							    		 HomeActivity.ArryScheduleTaskExecutor.get(i).shutdownNow();
							    	 }
							    	 scheduleTaskExecutorFlag=false;
							    	 HomeActivity.ArryScheduleTaskExecutor.clear();
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
									 for(int i=0;i<HomeActivity.ArryScheduleTaskExecutor.size();i++){
							    		 Log.d("tag", "ArryScheduleTaskExecutor for expection :"+HomeActivity.ArryScheduleTaskExecutor.size());
							    		 HomeActivity.ArryScheduleTaskExecutor.get(i).shutdownNow();
							    	 }
									
							    	 scheduleTaskExecutorFlag=false;
							    	 HomeActivity.ArryScheduleTaskExecutor.clear();
								}
						    	
						    }
						});
						
					}
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
		thread.start();
	}
	
	static class ViewHolder
	{
		ImageView image;
		TextView text;
		CheckBox check;
	}
	
	@Override
	protected void onDestroy() 
	{
		super.onDestroy();
	}

	@Override
	public void onConnected() 
	{
		
		runOnUiThread(new Runnable() {
		     @Override
		     public void run() {
		    	showToast("Connected to ip: "+CONNECTED_PRINTER_IP);
		 		if(adapter!=null)
		 		adapter.notifyDataSetChanged();
		 		

		    }
		});
		
	}

	@Override
	public void onDisconnected() 
	{
		showToast("Disconnected to ip: "+CONNECTED_PRINTER_IP);
		connectedAddress="";
		if(adapter!=null)
		adapter.notifyDataSetChanged();
	/*	if (autoDisconnect) {
			if (MainActivity.relProgress!=null) {
				if (!(MainActivity.activity.isFinishing())) {
					startActivity(new Intent(MainActivity.activity,
							WiFiActivity.class));
					MainActivity.activity.finish();
				}
			}	
		}*/
		
		
	}

	@Override
	public void onError(String arg0) 
	{	
		Log.i("tag", "onError");
		if (arg0.contains("failed to connect to")) {
			Log.i("tag", "arg0 java.net.ConnectException ");
			
		}else{
		showToast("Printer Error: "+arg0);
		}
	}
	public static boolean validate(final String ip){          

	      Pattern pattern = Pattern.compile(PATTERN);
	      Matcher matcher = pattern.matcher(ip);
	      return matcher.matches();             
	}
	Boolean isconnect = true;
	private  void printerConnectivityDetector(final Context ctx, final String ipAddress)
	{
		socketconnectionCheck=false;
		socketDialogShowCheck=false;
		scheduleTaskExecutor = Executors.newScheduledThreadPool(5);
	
		scheduleTaskExecutor.scheduleAtFixedRate(new Runnable() {
			  public void run()
			  {
				  	 try{
				  		 InetAddress pingAddr = null;
				  		 pingAddr = InetAddress.getByName(CONNECTED_PRINTER_IP);
				  		Log.d("tag", "ArryScheduleTaskExecutor printerConnectivityDetector before:"+HomeActivity.ArryScheduleTaskExecutor.size());
				  		 if (!scheduleTaskExecutorFlag) {
				  			 Log.i("tag", "scheduleTaskExecutorFlag added");
				  			HomeActivity.ArryScheduleTaskExecutor.add(scheduleTaskExecutor);
				  			scheduleTaskExecutorFlag=true;
						}
				  		Log.d("tag", "ArryScheduleTaskExecutor printerConnectivityDetector after:"+HomeActivity.ArryScheduleTaskExecutor.size());
				  		/* if (!pingAddr.isReachable(300))
				  		 {
				  			 Log.i("Status ","Printer Disconnected");
				  			
				  			((Activity) ctx).runOnUiThread(new Runnable() 
				  			{
				  				public void run() 
				  				{
				  					scheduleTaskExecutor.shutdownNow() ;
//				  					disconnect();
				  					connectedAddress="";
				  					if(adapter!=null)
				  					adapter.notifyDataSetChanged();
				  					if (autoDisconnect) {
				  						isConnected=false;
				  						if (MainActivity.relProgress!=null) {
				  							if (!(MainActivity.activity.isFinishing())) {
				  								startActivity(new Intent(MainActivity.activity,
				  										WiFiActivity.class));
				  								MainActivity.activity.finish();
				  							}
				  						}	
				  					}
				  				}
				  			});
				  			
				  		 }*/
				  		if (!pingAddr.isReachable(300)) {
							Log.i("Status ", "Printer Disconnected");

							((Activity) ctx).runOnUiThread(new Runnable() {
								public void run() {
									// jagan check
//									if (disconnectionCountCheck > 1) {
										if (socketconnectionCheck) {
											if (!socketDialogShowCheck) {
												if (isconnect) {
													Log.d("test", "going to close connection");
//												closeConnection();
												isconnect = false;
												}else{
													Log.d("test", "connection not closed");	
												}
											socketDialogShowCheck=true;
											if (MainActivity.relProgress!=null) {
												MainActivity.relProgress.setVisibility(View.VISIBLE);
//												MainActivity.activity.finish();
											}
											
											if(!(activity.isFinishing()))
											{
											    showProgress("Wait Printer Reconnecting.. ",activity);
											}
										
										}
										}
										
//										disconnect();
//										scheduleTaskExecutor.shutdownNow();
										Log.d("test", "2");	
										
//									} else {
//										
//										disconnectionCountCheck++;
//										Log.i("test", "count :"
//												+ disconnectionCountCheck);
//									}

								}
							});

						} else {
							Log.i("test", "connected");
							
							socketconnectionCheck=true;
							if(socketDialogShowCheck){
								socketDialogShowCheck=false;
							}
							((Activity) ctx).runOnUiThread(new Runnable() {
								public void run() {
							 if (MainActivity.relProgress!=null) {
								 if (MainActivity.relProgress!=null) {
									MainActivity.relProgress.setVisibility(View.GONE);
									MainActivity.tvConnectedIP.setText("Connected to ip :"+WiFiActivity.CONNECTED_PRINTER_IP);
								 }
								}
							 if(!(activity.isFinishing()))
								{
								hideProgress(activity);
								}
								}
							});
							disconnectionCountCheck = 0;
							if (!isconnect) {
								Log.d("test", "2");
								isconnect = true;
								connection.openConnection(ipAddress);
								
							}
						}
				  	 }
				  	 catch(Exception e)
				  	 {
				  		 e.printStackTrace();
				  		if (e.getMessage().contains("ECONNREFUSED")) {
							Log.i("tag", "java.net.ConnectException ");
							Log.i("tag", "CONNECTED_PRINTER_IP:"+CONNECTED_PRINTER_IP+" ipAddress:"+ipAddress);
							if(CONNECTED_PRINTER_IP.equals(ipAddress)){
				  		CONNECTED_PRINTER_IP = ipAddress;
						isConnected = true;
						connectedAddress =ipAddress;
						
						runOnUiThread(new Runnable() {
						     @Override
						     public void run() 
						     {
						    	 if(isManualConnection)
						    	 {
						    		
						    		 connect_button.setText("Disconnect");
						    		 //jagan start
						    		 Device dev=new Device(CONNECTED_PRINTER_IP, "");
					    			 list.add(dev);
					    			 if(list!=null && list.size()>0)
					 				{
					 					adapter=new ListAdapter();
					 					printer_list.setAdapter(adapter);
					 					
					 					
					 				}
					    			 //jagan end
//						    		 scanPrinters();
						    	 }
						    	 isConnectedToWifi=true;
						    	  adapter.notifyDataSetChanged();	
						    	  showToast("CONNECTED TO IP: "+CONNECTED_PRINTER_IP);
							 }
						   
						});
				  	 }
				  		}
				  	 }
			  }
			}, 0, 2, TimeUnit.SECONDS);
		
	}
	
	
	

	
	public void reConnection(final String address) {
		disconnect();
		new Timer().schedule(new TimerTask() {          
		    @Override
		    public void run() {
		        // this code will be executed after 2 seconds     
		    	connect(address);
		    }
		}, 5000);
		
		
	}
	

}
