package com.ui.ctpgapp;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.cognitive.printer.io.POSPrinterIO;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


public class FileActivity extends Activity
{
	private ProgressDialog barProgressDialog;
	private String[] fileName={};
	
	private ListView listView;
	private ArrayAdapter<String> adapter;
	public List<File> list=new ArrayList<File>();
	private Handler handler=new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.file_printing);
		listView=(ListView) findViewById(R.id.file_list);
		listView.setOnItemClickListener(new OnItemClickListener() 
		{
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,long arg3) 
			{
				sendFile(list.get(arg2));
			}
		});
		scanBinFiles();
	}

	private void showProgress()
	{
		barProgressDialog=ProgressDialog.show(this, "File Browser", "Loading Bin Files...");
		barProgressDialog.setCancelable(false);
	}
	
	private void hideProgress()
	{
		if(barProgressDialog!=null)
			barProgressDialog.dismiss();
	}
	
	private void getFileNames()
	{
		int fileCount=list.size();
		if(fileCount>0)
		{
			fileName=new String[fileCount];
			for(int i=0;i<fileCount;i++)
			{
				File file=list.get(i);
				fileName[i]=file.getName();
			}
		}
		else
		{
			showToast("No Bin Files Found!");
		}
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(FileActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	
	private void scanBinFiles()
	{
		showProgress();
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				File root=Environment.getExternalStorageDirectory();
				if(root!=null)
				{
					getBinFiles(root);
				}
				
				String secondary_sd = System.getenv("SECONDARY_STORAGE");
				if(secondary_sd != null)
				{
					File sdcard=new File(secondary_sd);
					if(sdcard!=null)
					{
						getBinFiles(sdcard);
					}
				}
				
				handler.post(new Runnable() 
				{
					public void run() 
					{
						hideProgress();
						getFileNames();
						adapter=new ArrayAdapter<String>(FileActivity.this, android.R.layout.simple_list_item_1, fileName);
						listView.setAdapter(adapter);
						//adapter.notifyDataSetChanged();
					}
				});
			}
		});
		thread.start();
	}
	
	public void getBinFiles(File root)
	{
		if(root.isDirectory())
		{
			File[] files=root.listFiles();
			if(files!=null)
			{
				for(File f:files)
				{
					if(f.isFile())
					{
						String ext=getExtension(f);
						if(ext!=null && ext.equalsIgnoreCase("bin"))
						{
							list.add(f);
						}
					}
					else
					{
						getBinFiles(f);
					}
				}
			}
		}
	}
	
	public static String getExtension(File f) 
	{
        String ext = null;
        String s = f.getName();
        int i = s.lastIndexOf('.');

        if (i > 0 && i < s.length() - 1) 
        {
            ext = s.substring(i + 1).toLowerCase();
        }
        return ext;
    }
	
	private void sendFile(final File file)
	{
		try 
		{
			InputStream is=new FileInputStream(file);
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();

			int nRead;
			byte[] data = new byte[16384];

			while ((nRead = is.read(data, 0, data.length)) != -1) 
			{
				buffer.write(data, 0, nRead);
			}
			buffer.flush();
			byte[] binary=buffer.toByteArray();
			
			POSPrinterIO pos=new POSPrinterIO();
			pos.addResetPrinter();
			pos.addBinaryData(binary);
			
			if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
			{
				BluetoothActivity.printer.sendCommand(pos);
			}
			else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
			{
				sendToPrinter(pos);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private void sendToPrinter(final POSPrinterIO buffer)
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					WiFiActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
		thread.start();
	}
	
}
