package com.ui.ctpgapp;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class PrinterInfoActivity extends Activity
{
	private TextView model;
	private TextView serial_number;
	private TextView software_version;
	private TextView boot_version;
	private TextView flash_version;
	
	private Handler handler=new Handler();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.print_info);
		model=(TextView) findViewById(R.id.model);
		serial_number=(TextView) findViewById(R.id.serial_number);
		software_version=(TextView) findViewById(R.id.software_version);
		boot_version=(TextView) findViewById(R.id.boot_version);
		flash_version=(TextView) findViewById(R.id.flash_version);
		getPrinterInfo();
	}
	
	private void getPrinterInfo()
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					String data="";
					
					data="Printer Model"+"\r\n";
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						Log.i("getPrinterInfo", "Printer Model :"+WiFiActivity.printer.getPrinterModel());
						 if(WiFiActivity.printer.getPrinterModel().contains("'"))
    					 {
							 data+= WiFiActivity.printer.getPrinterModel().substring(1);
    					 }
    					 else
    					 {
    						 data+= WiFiActivity.printer.getPrinterModel();
    					 }
//						data+= WiFiActivity.printer.getPrinterModel().substring(1);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{ 
						Log.i("getPrinterInfo", "Printer Model :"+WiFiActivity.printer.getPrinterModel());
						 if(WiFiActivity.printer.getPrinterModel().contains("'"))
   					 {
							 data+= WiFiActivity.printer.getPrinterModel().substring(1);
   					 }
   					 else
   					 {
   						 data+= WiFiActivity.printer.getPrinterModel();
   					 }
						/*Log.i("getPrinterInfo", "Printer Model :"+BluetoothActivity.printer.getPrinterModel());
						data+= BluetoothActivity.printer.getPrinterModel().substring(1);*/
					}
					showInfo(model, data);
					
					data="Serial Number"+"\r\n";
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						data+= WiFiActivity.printer.getSerialNumber();
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						data+= BluetoothActivity.printer.getSerialNumber();
					}
					showInfo(serial_number, data);
					
					data="Software Version"+"\r\n";
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						data+= WiFiActivity.printer.getSoftwareVersion().substring(4);
						Log.i("getSoftwareVersion", "Software Version :"+WiFiActivity.printer.getSoftwareVersion());
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						data+= BluetoothActivity.printer.getSoftwareVersion().substring(4);
						Log.i("getSoftwareVersion", "Software Version :"+WiFiActivity.printer.getSoftwareVersion());
					}
					showInfo(software_version, data);
					
					data="Loader Version"+"\r\n";
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						Log.i("getPrinterInfo", "Loader firmware Version :"+WiFiActivity.printer.getBootFirmwareVersion());
//						data+= WiFiActivity.printer.getBootFirmwareVersion();
						data+= WiFiActivity.printer.getSoftwareVersion().substring(0, 4);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
//						data+= BluetoothActivity.printer.getBootFirmwareVersion();
						data+= BluetoothActivity.printer.getSoftwareVersion().substring(0, 4);
					}
					showInfo(boot_version, data);
					
					data="Flash Version"+"\r\n";
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						data+= WiFiActivity.printer.getFlashFirmwareVersion();
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						data+= BluetoothActivity.printer.getFlashFirmwareVersion();
					}
					showInfo(flash_version, data);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Communication Error");
				}
			}
		});
		thread.start();
	}
	
	private void showInfo(final TextView view,final String data)
	{
		handler.post(new Runnable() 
		{
			public void run() 
			{
				view.setText(data);
			}
		});
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(PrinterInfoActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
	
}
