package com.ui.ctpgapp;

import com.cognitive.printer.io.POSPrinterIO;
import com.cognitive.printer.io.POSPrinterIO.Alignment;
import com.cognitive.printer.io.POSPrinterIO.CorrectionLevelOption;
import com.cognitive.printer.io.POSPrinterIO.Model;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class QRCodeActivity extends Activity
{

	private Button print_button;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.qrcode_printing);
		print_button=(Button) findViewById(R.id.btn_print);
		print_button.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View v) 
			{
				try 
				{	
					POSPrinterIO buffer=new POSPrinterIO();
					buffer.addInitializePrinter();
					buffer.addAlignment(Alignment.Center);
					buffer.addQRCode(Model.Model2,5,CorrectionLevelOption.Low,"QR Code by CognitiveTPG".getBytes());
					Byte[] cmd={0x0D,0x0A};
					buffer.addCommand(cmd);
					buffer.addData("For more information please visit us at:".getBytes());
					buffer.addCommand(cmd);
					buffer.addData("http://www.cognitivetpg.com/gettheinsidestory".getBytes());
					buffer.printQRCode();
					
					if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_BLUETOOTH)
					{
						BluetoothActivity.printer.sendCommand(buffer);
					}
					else if(HomeActivity.MODE_CONNECTION==HomeActivity.MODE_WIFI)
					{
						sendToPrinter(buffer);
					}
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
	}

	private void sendToPrinter(final POSPrinterIO buffer)
	{
		Thread thread=new Thread(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					WiFiActivity.printer.sendCommand(buffer);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					showToast("Failed to Print");
				}
			}
		});
		thread.start();
	}
	
	private void showToast(final String msg)
	{
		this.runOnUiThread(new Runnable() 
		{
			public void run() 
			{
				Toast.makeText(QRCodeActivity.this, msg, Toast.LENGTH_LONG).show();
			}
		});
	}
}
