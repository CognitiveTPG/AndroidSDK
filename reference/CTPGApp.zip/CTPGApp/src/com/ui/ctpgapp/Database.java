package com.ui.ctpgapp;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

public class Database extends SQLiteOpenHelper 
{
	private static final String DATABASE_NAME = "pos.db";
	private static final int SCHEMA_VERSION = 4;
	private SQLiteDatabase db;
	private Context mContext;

	interface Tables 
	{
		String HISTORY = "HISTORY";
	}
	
	public Database(Context context) 
	{
		super(context, DATABASE_NAME, null, SCHEMA_VERSION);
		this.mContext = context;
	}

	@Override
	public void onCreate(SQLiteDatabase db) 
	{
		db.execSQL("CREATE TABLE " + Tables.HISTORY + " (" + BaseColumns._ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," 
				+ "Command"+ " TEXT)");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) 
	{
		db.execSQL("DROP TABLE IF EXISTS " + Tables.HISTORY);
		onCreate(db);
	}

	public void openDB() 
	{
		this.db = getWritableDatabase();
	}

	public void closeDB() 
	{
		super.close();
		db.close();
	}
	
	public void addCommand(final String cmd)
	{
		final ContentValues values = new ContentValues();
		values.put("Command", cmd);
		long id=db.insert(Tables.HISTORY, null, values);
		System.out.println("CMD Save "+id);
	}
	
	public ArrayList<String> getCommandList()
	{
		ArrayList<String> list=new ArrayList<String>();
		final Cursor cur = db.query(Tables.HISTORY, null, null, null, null,null, null);
		if (cur != null) 
		{
			if (cur.moveToFirst()) 
			{
				do 
				{
					String cmd = cur.getString(cur.getColumnIndex("Command"));
					list.add(cmd);
				} 
				while (cur.moveToNext());
			}
			cur.close();
			return list;
		} 
		else 
		{
			return list;
		}
	}
}
